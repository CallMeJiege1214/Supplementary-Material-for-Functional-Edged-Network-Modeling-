function [X_output, G_output, U_output] = adjust(X_in, G_in, U_in, X_true, G_true, U_true,t_start, t_end, seq)


seqtime = t_start:seq:t_end;
constant = sqrt(length(seqtime)/2); 
U_true{3} = U_true{3}/constant;

O = cell(1,3);
for i = 1:3 
   O{i} = (U_in{i}' * U_in{i}) \ U_in{i}' *U_true{i}; 
   U_output{i} = U_in{i} * O{i};
end
G_output = ttm(G_in, O, 't');
G_output = G_output/constant;
U_output{3} = U_output{3} * constant;
X_output = ttm(G_output, U_output);

end


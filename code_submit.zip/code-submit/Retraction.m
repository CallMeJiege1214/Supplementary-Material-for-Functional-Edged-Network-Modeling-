function [G_new, U_new, X_new] = Retraction(X,delta,r)
%RETRACTION Shrinkage operator based on SVD; computes the projection back to the Riemannian manifold
%           of X + delta
%input:X The current point on the Riemannian manifold
%     :delta The increment found in the tangent space (note: X + delta is the next point)
%     :r The Tucker rank, a 1��3 vector
%output:G_new, U_new, X_new The core tensor, factor matrices, and full tensor retracted onto the
%       Riemannian manifold; U_new is a 1��3 cell array

X_new = X + delta;
U_new = cell(1,3);
for i = 1:3
   U_new{i} = nvecs(X_new, i, r(i)); 
end
G_new = ttm(X_new, U_new, 't');
X_new = ttm(G_new, U_new);
end


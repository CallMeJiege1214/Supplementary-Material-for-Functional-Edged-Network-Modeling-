function output = Euc_to_Rie(A, G, U)
%EUC_TO_RIE Project tensor A from Euclidean space onto the Riemannian manifold at point X_pre
%input:A The target tensor to be projected
%     :G The Tucker core at point X_pre
%     :U A 1��3 cell array of Tucker factor matrices at point X_pre
%     :X_pre The tangent point on the Riemannian manifold for projection
%output:The projection result, which is a tensor


W = cell(1,3);
temp1 = eye(size(U{1}, 1)) - U{1} * U{1}';
temp2 = double(tenmat(ttm(A, {U{2}, U{3}}, [2, 3], 't'), 1));
temp = double(tenmat(G, 1));
temp3 = temp' /(temp *temp');
W{1} = temp1 * temp2 * temp3;

temp1 = eye(size(U{2}, 1)) - U{2} * U{2}';
temp2 = double(tenmat(ttm(A, {U{1}, U{3}}, [1, 3], 't'), 2));
temp = double(tenmat(G, 2));
temp3 = temp' /(temp *temp');
W{2} = temp1 * temp2 * temp3;

temp1 = eye(size(U{3}, 1)) - U{3} * U{3}';
temp2 = double(tenmat(ttm(A, {U{1}, U{2}}, [1, 2], 't'), 3));
temp = double(tenmat(G, 3));
temp3 = temp' /(temp *temp');
W{3} = temp1 * temp2 * temp3;

output = ttm(A, {U{1}*U{1}', U{2}*U{2}',U{3}*U{3}'}) + ttm(G, {W{1}, U{2}, U{3}}) + ...
     ttm(G, {U{1}, W{2}, U{3}}) + ttm(G, {U{1}, U{2}, W{3}});

end


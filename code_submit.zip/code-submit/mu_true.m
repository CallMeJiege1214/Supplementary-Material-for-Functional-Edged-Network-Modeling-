function output = mu_true(x)
output = 0;%x + 3;%formulation can change
end


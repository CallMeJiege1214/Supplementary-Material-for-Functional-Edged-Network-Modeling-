rep = 20; %%% number of sample 
m = 50; %%% number of nodes
n = m;
s1 = 15; %%% the first element of the rank 
s2 = s1;
K = 25; %% the third element of the rank
sigma = sqrt(0.2); %%Standard deviation of noise
w = 0.4;  %%missing rate
N = 20; 
t_start = -0.98;
t_end = 1;
seq = 0.02;
r = [s1, s1, K];
max_m = 5; 
tol = 1e-7; %tolerance
maxiter = 1000;
seqtime = t_start:seq:t_end;
N_min = round(length(seqtime)*(1-w));
N_max = round(length(seqtime)*(1-w));
mydim = [n, m, length(seqtime)]; 
Sigma = dif_mat(mydim(3)); 
alpha = 0.1 * ones(1, r(3)); %% smooth penalty
Alpha = diag(alpha); 

for tt = 1:rep
    [X_true , U_true, G_true]= generate_data_true(n,m,s1,s2,K,N, t_start, t_end, seq);%������ʵ�۲�
    myoutput(tt).G_true = G_true;
    myoutput(tt).U_true = U_true;
    
    [X_observe, Omiga, seqtime,X_observe_full ,X_observe_full_nornd] = generate_data_observe(X_true,N_min,N_max,t_start,t_end,seq,sigma); %������ɢ�۲�����
    myoutput(tt).Omiga = Omiga;
    myoutput(tt).X_observe_full = X_observe_full;
    myoutput(tt).X_observe_full_nornd = X_observe_full_nornd;
    
    X_observe_central = X_observe;
    myoutput(tt).X_observe_central = X_observe_central;
    
    [G_old, U_old, X_old] = Initialization_tucker(X_observe_central, r);

    %%%%%
    
    temp = grad_Euc(G_old, U_old, X_old, X_observe_central, Omiga, Sigma, Alpha); 
    eta_old = - Euc_to_Rie(temp, G_old, U_old);
    [G_new, U_new,X_new] = Retraction(X_old,eta_old,r);
    score_new = target_f(X_new, X_observe_central,Omiga, U_new{3},Sigma, alpha);
    [G_next,U_next,X_next,score_next,score_list] = conjugate_dradient(G_old, U_old, X_old,eta_old,...
        G_new, U_new, X_new,score_new,X_observe_central, Omiga, Sigma, Alpha,alpha,max_m,r, tol, maxiter);

    [X_output, G_output, U_output] = adjust(X_next, G_next, U_next, X_true, G_true, U_true,t_start, t_end, seq);
    [MSE,R2,Rec_esti, Rec_true,Cyc_esti, Cyc_true,InTwo_esti, ... 
        InTwo_true, OutTwo_esti,OutTwo_true,Densi_esti,Densi_true] = evlua(X_output, X_observe, X_observe_full,Omiga);
    
    score_list = [score_list, target_f(X_output, X_observe_central,Omiga, U_output{3},Sigma, alpha)];
    
    myoutput(tt).G_output = G_output;
    myoutput(tt).U_output = U_output;
    myoutput(tt).X_output = X_output;
    myoutput(tt).MSE = MSE;
    myoutput(tt).R2 = R2;
    myoutput(tt).Rec_esti = Rec_esti;
    myoutput(tt).Rec_true = Rec_true;
    myoutput(tt).Cyc_esti = Cyc_esti;
    myoutput(tt).Cyc_true = Cyc_true;
    myoutput(tt).InTwo_esti = InTwo_esti;
    myoutput(tt).InTwo_true = InTwo_true;
    myoutput(tt).OutTwo_esti = OutTwo_esti;
    myoutput(tt).OutTwo_true = OutTwo_true;
    myoutput(tt).Densi_esti = Densi_esti;
    myoutput(tt).Densi_true = Densi_true;
    myoutput(tt).score_list = score_list;

    %%%
    res = X_output - X_observe_full;
    res = res(:);
    warning('off','all');
    [h,p] = lillietest(res);
    myoutput(tt).normal_p = p;
    e = res;
    dw = sum(diff(e).^2) / sum(e.^2);
    myoutput(tt).dw = dw; 
    sprintf('estimate %d-th sample', tt)
end

figure
boxplot([vertcat(myoutput.Rec_esti),vertcat(myoutput.Rec_true)])
set(gca, 'XTickLabel', {'Rec_esti','Rec_true'});
title('Comparison of Estimated and True Reciprocity');

figure
boxplot([vertcat(myoutput.Cyc_esti),vertcat(myoutput.Cyc_true)])
set(gca, 'XTickLabel', {'Cyc_esti','Cyc_true'});
title('Comparison of Estimated and True Cyclic triads');

figure
boxplot([vertcat(myoutput.InTwo_esti),vertcat(myoutput.InTwo_true)])
set(gca, 'XTickLabel', {'InTwo_esti','InTwo_true'});
title('Comparison of Estimated and True In-two-stars');

figure
boxplot([vertcat(myoutput.OutTwo_esti),vertcat(myoutput.OutTwo_true)])
set(gca, 'XTickLabel', {'InTwo_esti','OutTwo_true'});
title('Comparison of Estimated and True Out-two-stars');

figure
boxplot([vertcat(myoutput.normal_p)])
title('Boxplot of p_{normal}');

figure
boxplot([vertcat(myoutput.dw)])
title('Boxplot of dw');

fprintf('MSE = %.4f(%.4f)\n', mean(vertcat(myoutput.MSE)),std(vertcat(myoutput.MSE)))
fprintf('R2 = %.4f(%.4f)\n', mean(vertcat(myoutput.R2)),std(vertcat(myoutput.R2)))

%%myoutput.X_output is the final estimation of myoutput.X_observe

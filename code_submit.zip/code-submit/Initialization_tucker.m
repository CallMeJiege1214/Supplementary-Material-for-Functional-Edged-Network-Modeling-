function [G,U,X_pre] = Initialization_tucker(X, r)
%INITIALIZATION_TUCKER Used to compute the initialization for Tucker decomposition
%input:X The input observed tensor, i.e., the centered discrete observations
%     :r A 1��3 vector specifying the Tucker rank in each of the three modes
%output:G The initial Tucker core tensor
%      :U A 1��3 cell array, where each element is an initial Tucker factor matrix
%      :X_pre The tensor obtained by multiplying G and U

U = cell(1,3);
for i = 1:3
   ten_mat = tenmat(X, i);
   temp = ten_mat * ten_mat';
   temp = double(temp) - diag(diag(double(temp)));
   [V, ~] = eig(temp);
   U{i} = V(:,1:r(i));
end
G = ttm(X, U, 't');
X_pre = ttm(G, U);
end


function output = vector_transport(epsilon_old, G_new, U_new)
%VECTOR_TRANSPORT y is used to compute the transported vector in the conjugate gradient iteration,
%                 transported from epsilon_old
%input:elpsion_old The descent tensor from the previous iteration, or any tensor to be transported
%     :G_new The current Tucker core tensor
%     :U_new The current Tucker factor matrices, a 1��3 cell
%output:The transported tensor, which can be used for the next conjugate update

V = cell(1, 3);
temp1 = eye(size(U_new{1}, 1)) - U_new{1} * U_new{1}';
temp2 = double(tenmat(ttm(epsilon_old, {U_new{2}, U_new{3}}, [2,3], 't'), 1));
temp = double(tenmat(G_new, 1));
temp3 = temp' / (temp *temp');
V{1} = temp1 * temp2 * temp3;

temp1 = eye(size(U_new{2}, 1)) - U_new{2} * U_new{2}';
temp2 = double(tenmat(ttm(epsilon_old, {U_new{1}, U_new{3}}, [1,3], 't'), 2));
temp = double(tenmat(G_new, 2));
temp3 = temp' / (temp *temp');
V{2} = temp1 * temp2 * temp3;

temp1 = eye(size(U_new{3}, 1)) - U_new{3} * U_new{3}';
temp2 = double(tenmat(ttm(epsilon_old, {U_new{1}, U_new{2}}, [1,2], 't'), 3));
temp = double(tenmat(G_new, 3));
temp3 = temp' / (temp *temp');
V{3} = temp1 * temp2 * temp3;

output = ttm(epsilon_old, {U_new{1}*U_new{1}', U_new{2}*U_new{2}', U_new{3}*U_new{3}'})+...
    ttm(G_new, {V{1}, U_new{2}, U_new{3}}) + ttm(G_new, {U_new{1}, V{2}, U_new{3}}) + ...
    ttm(G_new, {U_new{1}, U_new{2}, V{3}});
end

